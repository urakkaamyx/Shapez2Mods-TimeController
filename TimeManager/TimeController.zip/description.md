🕒 Time Controls

Adds a time control HUD to Shapez 2, letting you pause or adjust simulation speed directly from the top-right corner of the interface.

no console commands, no manual setup, just clean in-game buttons.

🎮 Features

⏸️ Pause the game instantly

▶️ Resume at normal speed (1x)

⚙️ Speed Levels
Button	Speed	Description
II	0x	Pause
>	1x	Normal
>>	5x	Fast
>>>	10x	Very Fast
>|	25x	Ultra Speed